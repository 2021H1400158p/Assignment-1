#include <linux/version.h>
#include <linux/kernel.h>
#include <linux/types.h>
#include <linux/kdev_t.h>
#include <linux/fs.h>
#include <linux/device.h>
#include <linux/cdev.h>
#include <linux/moduleparam.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/ioctl.h>



#define WR_MODE _IOW('a','a',int32_t*)
#define RD_MODE _IOR('a','b',int32_t*)

static dev_t first;           //Global Variable for the Driver
static struct cdev c_dev;    //Variable for the Character device structure
static struct class *cls;    //Variable for the Device class
#define "ioctl name" __IOX("200","ADC","char")
ioctl(fd, WR_MODE, (int32_t*) &number); 

ioctl(fd, RD_MODE, (int32_t*) &value);
/*
** This function will be called when we write IOCTL on the Device file
*/
static long etx_ioctl(struct file *file, unsigned int mode, unsigned long arg)
{
         switch(mode) {
                case WR_MODE:
                        if( copy_from_user(&value ,(int32_t*) arg, sizeof(value)) )
                        {
                                pr_err("Mode Written : Err!\n");
                        }
                        pr_info("Value = %d\n", value);
                        break;
                case RD_MODE:
                        if( copy_to_user((int32_t*) arg, &value, sizeof(value)) )
                        {
                                pr_err("Mode Read : Err!\n");
                        }
                        break;
                default:
                        pr_info("Default\n");
                        break;
        }
        return 0;
}



/* The deinitions of the functions my_open, my_close, my_read, my_write which can be called by .open, .release, .read and .write operators respectively is given below */

static int my_open(struct inode *i, struct file *f)
{
	printk(KERN_INFO "ADC : open()");
	return 0;
}

static int my_close(struct inode *i, struct file *f)
{
	printk(KERN_INFO "ADC : close()");
	return 0;
}

static ssize_t my_read(struct file *f, char __user *buf, size_t len, loff_t *off)
{
	printk(KERN_INFO "ADC : read()");
	return 0;
}

static ssize_t my_write(struct file *f, const char __user *buf, size_t len, loff_t *off)
{
	printk(KERN_INFO "ADC : write()");
	return 0;
}

/* IOCTL Function Call */
	
int my_ioctl(struct inode *inode, struct file *file, unsigned int ioctl_num, unsigned long ioctl_param)
{
switch (ioctl_num)
  {
	case IOCTL_SELECT_MODE:
	
	     //It does operations specific to request call IOCTL_SET_MSG
	break;
	case GET_MSG:
	     //It does operations specific to request call IOCTL_GET_MSG
	break;
	case GET_NTH_BYTE:
	     //It does operations specific to request call IOCTL_GET_NTH_BYTE
	break;
  }
  return SUCCESS;  

}



//*************************************************
static struct file_operations fops = 
{
	.owner   =   THIS_MODULE,
	.read    =   my_read,
	.write   =   my_write,
	.open    =   my_open,
	.release =   my_close,
	//.ioctl   =   my_ioctl,
	.unlocked_ioctl = my_ioctl
};
//*************************************************

static int __init adc_init(void)  /* Constructor */
{

//Step 1: Reserve <Major,Minor>
	printk(KERN_INFO "ADC registered\n\n");
	if (alloc_chrdev_region(&first, 0, 3, "BITS-PILANI") < 0)
	{
		return -1;
	}
	
	
	
//Step 2: Dynamically create Device Node in /dev directory
	if ((cls = class_create(THIS_MODULE, "chardev")) == NULL)
	{
		unregister_chrdev_region(first, 1);
		return -1;
	}
	if (device_create(cls, NULL, first, NULL, "ADC-DEV") == NULL)
	{
		class_destroy(cls);
		unregister_chrdev_region(first, 1);
		return -1;
	}

//Step 3: Link fops and cdev to Device Node
	cdev_init(&c_dev, &fops);
	if (cdev_add(&c_dev, first, 1) == -1)
	{
		device_destroy(cls, first);
		class_destroy(cls);
		unregister_chrdev_region(first, 1);
		return -1;
	}
	
	
	printk(KERN_INFO "<MAJOR, MINOR> : <%d, %d>\n", MAJOR(first), MINOR(first));
	return 0;
}


static void __exit adc_exit(void)  /* Destructor */
{
	cdev_del(&c_dev);
	device_destroy(cls, first);
	class_destroy(cls);
	unregister_chrdev_region(first, 3);
	printk(KERN_INFO "ADC unregistered\n\n");
}


module_init(adc_init);
module_exit(adc_exit);
MODULE_LICENSE("GPL");



